package android.util;
public final class Log {
    public static int d(String t, String m) { return 0; } public static int i(String t, String m) { return 0; }
    public static int w(String t, String m) { return 0; } public static int e(String t, String m) { return 0; }
    public static int v(String t, String m) { return 0; }
    public static int e(String t, String m, Throwable tr) { return 0; } public static int w(String t, String m, Throwable tr) { return 0; }
    public static int d(String t, String m, Throwable tr) { return 0; } public static int i(String t, String m, Throwable tr) { return 0; } public static int v(String t, String m, Throwable tr) { return 0; }
}
